//Juan Ignacio Ar�valo Toc IV "C" Clave: 3
Algoritmo Lecc16_Act3_Inc1
	Escribir "Juan Ignacio Ar�valo Toc IVC Clave: 3"
	
    Dimension numerosEnteros[15]

    Definir indice, comparador Como Entero
    Definir existeRepetido Como Logico

    existeRepetido <- Falso

    Para indice <- 1 Hasta 15 Hacer
        Escribir "Ingrese el n�mero ", indice, ": "
        Leer numerosEnteros[indice]
    FinPara

    Para indice <- 1 Hasta 14 Hacer
        Para comparador <- indice + 1 Hasta 15 Hacer
            Si numerosEnteros[indice] = numerosEnteros[comparador] Entonces
                existeRepetido <- Verdadero
            FinSi
        FinPara
    FinPara

    Si existeRepetido Entonces
        Escribir "S� existe al menos un n�mero repetido."
    SiNo
        Escribir "No existe ning�n n�mero repetido."
    FinSi

FinAlgoritmo

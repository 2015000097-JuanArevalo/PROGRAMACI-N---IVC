//Juan Ignacio Ar�valo Toc IV "C" Clave: 3
Algoritmo Lecc16_Act2_Inc2
	Escribir "Juan Ignacio Ar�valo Toc IVC Clave: 3"
	
    Dimension numerosEnteros[8]

    Definir indice, numeroMayor, posicionMayor Como Entero

    Para indice <- 1 Hasta 8 Hacer
        Escribir "Ingrese el n�mero ", indice, ": "
        Leer numerosEnteros[indice]

        Si indice = 1 Entonces
            numeroMayor <- numerosEnteros[indice]
            posicionMayor <- indice
        SiNo
            Si numerosEnteros[indice] > numeroMayor Entonces
                numeroMayor <- numerosEnteros[indice]
                posicionMayor <- indice
            FinSi
        FinSi
    FinPara

    Escribir "El n�mero mayor es: ", numeroMayor
    Escribir "Se encuentra en la posici�n: ", posicionMayor

FinAlgoritmo

﻿namespace GUIA_2_IV_UNIDAD_PROGRA_JuanArevalo_3IVC
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        private void InitializeComponent()
        {
            this.etPantalla = new System.Windows.Forms.Label();

            this.btDigito7 = new System.Windows.Forms.Button();
            this.btDigito8 = new System.Windows.Forms.Button();
            this.btDigito9 = new System.Windows.Forms.Button();

            this.btDigito4 = new System.Windows.Forms.Button();
            this.btDigito5 = new System.Windows.Forms.Button();
            this.btDigito6 = new System.Windows.Forms.Button();

            this.btDigito1 = new System.Windows.Forms.Button();
            this.btDigito2 = new System.Windows.Forms.Button();
            this.btDigito3 = new System.Windows.Forms.Button();

            this.btDigito0 = new System.Windows.Forms.Button();

            this.btIniciar = new System.Windows.Forms.Button();
            this.btBorrarEntrada = new System.Windows.Forms.Button();

            this.btDividir = new System.Windows.Forms.Button();
            this.btMenos = new System.Windows.Forms.Button();

            this.btPor = new System.Windows.Forms.Button();
            this.btMas = new System.Windows.Forms.Button();

            this.btComaDec = new System.Windows.Forms.Button();
            this.btIgual = new System.Windows.Forms.Button();
            this.btTantoPorCiento = new System.Windows.Forms.Button();

            this.SuspendLayout();

            // 
            // etPantalla
            // 
            this.etPantalla.AutoSize = false;
            this.etPantalla.BackColor =
                System.Drawing.Color.FromArgb(
                    ((int)(((byte)(255)))),
                    ((int)(((byte)(255)))),
                    ((int)(((byte)(192)))));

            this.etPantalla.BorderStyle =
                System.Windows.Forms.BorderStyle.Fixed3D;

            this.etPantalla.Font =
                new System.Drawing.Font(
                    "MS Sans Serif",
                    14.25F,
                    System.Drawing.FontStyle.Bold,
                    System.Drawing.GraphicsUnit.Point,
                    ((byte)(0)));

            this.etPantalla.Location =
                new System.Drawing.Point(12, 12);

            this.etPantalla.Name = "etPantalla";

            this.etPantalla.Size =
                new System.Drawing.Size(222, 27);

            this.etPantalla.TabIndex = 39;

            this.etPantalla.Text = "0,";

            this.etPantalla.TextAlign =
                System.Drawing.ContentAlignment.MiddleRight;

            // 
            // btDigito7
            // 
            this.btDigito7.Location =
                new System.Drawing.Point(12, 50);

            this.btDigito7.Name = "btDigito7";

            this.btDigito7.Size =
                new System.Drawing.Size(38, 28);

            this.btDigito7.TabIndex = 0;
            this.btDigito7.Text = "7";
            this.btDigito7.UseVisualStyleBackColor = true;

            this.btDigito7.Click +=
                new System.EventHandler(this.btDigito_Click);

            // 
            // btDigito8
            // 
            this.btDigito8.Location =
                new System.Drawing.Point(56, 50);

            this.btDigito8.Name = "btDigito8";

            this.btDigito8.Size =
                new System.Drawing.Size(38, 28);

            this.btDigito8.TabIndex = 1;
            this.btDigito8.Text = "8";
            this.btDigito8.UseVisualStyleBackColor = true;

            this.btDigito8.Click +=
                new System.EventHandler(this.btDigito_Click);

            // 
            // btDigito9
            // 
            this.btDigito9.Location =
                new System.Drawing.Point(100, 50);

            this.btDigito9.Name = "btDigito9";

            this.btDigito9.Size =
                new System.Drawing.Size(38, 28);

            this.btDigito9.TabIndex = 2;
            this.btDigito9.Text = "9";
            this.btDigito9.UseVisualStyleBackColor = true;

            this.btDigito9.Click +=
                new System.EventHandler(this.btDigito_Click);

            // 
            // btIniciar
            // 
            this.btIniciar.Location =
                new System.Drawing.Point(144, 50);

            this.btIniciar.Name = "btIniciar";

            this.btIniciar.Size =
                new System.Drawing.Size(38, 28);

            this.btIniciar.TabIndex = 3;
            this.btIniciar.Text = "C";
            this.btIniciar.UseVisualStyleBackColor = true;

            this.btIniciar.Click +=
                new System.EventHandler(this.btIniciar_Click);

            // 
            // btBorrarEntrada
            // 
            this.btBorrarEntrada.Location =
                new System.Drawing.Point(188, 50);

            this.btBorrarEntrada.Name = "btBorrarEntrada";

            this.btBorrarEntrada.Size =
                new System.Drawing.Size(46, 28);

            this.btBorrarEntrada.TabIndex = 4;
            this.btBorrarEntrada.Text = "CE";
            this.btBorrarEntrada.UseVisualStyleBackColor = true;

            this.btBorrarEntrada.Click +=
                new System.EventHandler(this.btBorrarEntrada_Click);

            // 
            // btDigito4
            // 
            this.btDigito4.Location =
                new System.Drawing.Point(12, 84);

            this.btDigito4.Name = "btDigito4";

            this.btDigito4.Size =
                new System.Drawing.Size(38, 28);

            this.btDigito4.TabIndex = 5;
            this.btDigito4.Text = "4";
            this.btDigito4.UseVisualStyleBackColor = true;

            this.btDigito4.Click +=
                new System.EventHandler(this.btDigito_Click);

            // 
            // btDigito5
            // 
            this.btDigito5.Location =
                new System.Drawing.Point(56, 84);

            this.btDigito5.Name = "btDigito5";

            this.btDigito5.Size =
                new System.Drawing.Size(38, 28);

            this.btDigito5.TabIndex = 6;
            this.btDigito5.Text = "5";
            this.btDigito5.UseVisualStyleBackColor = true;

            this.btDigito5.Click +=
                new System.EventHandler(this.btDigito_Click);

            // 
            // btDigito6
            // 
            this.btDigito6.Location =
                new System.Drawing.Point(100, 84);

            this.btDigito6.Name = "btDigito6";

            this.btDigito6.Size =
                new System.Drawing.Size(38, 28);

            this.btDigito6.TabIndex = 7;
            this.btDigito6.Text = "6";
            this.btDigito6.UseVisualStyleBackColor = true;

            this.btDigito6.Click +=
                new System.EventHandler(this.btDigito_Click);

            // 
            // btDividir
            // 
            this.btDividir.Location =
                new System.Drawing.Point(144, 84);

            this.btDividir.Name = "btDividir";

            this.btDividir.Size =
                new System.Drawing.Size(38, 28);

            this.btDividir.TabIndex = 8;
            this.btDividir.Text = "/";
            this.btDividir.UseVisualStyleBackColor = true;

            this.btDividir.Click +=
                new System.EventHandler(this.btOperacion_Click);

            // 
            // btMenos
            // 
            this.btMenos.Location =
                new System.Drawing.Point(188, 84);

            this.btMenos.Name = "btMenos";

            this.btMenos.Size =
                new System.Drawing.Size(46, 28);

            this.btMenos.TabIndex = 9;
            this.btMenos.Text = "-";
            this.btMenos.UseVisualStyleBackColor = true;

            this.btMenos.Click +=
                new System.EventHandler(this.btOperacion_Click);

            // 
            // btDigito1
            // 
            this.btDigito1.Location =
                new System.Drawing.Point(12, 118);

            this.btDigito1.Name = "btDigito1";

            this.btDigito1.Size =
                new System.Drawing.Size(38, 28);

            this.btDigito1.TabIndex = 10;
            this.btDigito1.Text = "1";
            this.btDigito1.UseVisualStyleBackColor = true;

            this.btDigito1.Click +=
                new System.EventHandler(this.btDigito_Click);

            // 
            // btDigito2
            // 
            this.btDigito2.Location =
                new System.Drawing.Point(56, 118);

            this.btDigito2.Name = "btDigito2";

            this.btDigito2.Size =
                new System.Drawing.Size(38, 28);

            this.btDigito2.TabIndex = 11;
            this.btDigito2.Text = "2";
            this.btDigito2.UseVisualStyleBackColor = true;

            this.btDigito2.Click +=
                new System.EventHandler(this.btDigito_Click);

            // 
            // btDigito3
            // 
            this.btDigito3.Location =
                new System.Drawing.Point(100, 118);

            this.btDigito3.Name = "btDigito3";

            this.btDigito3.Size =
                new System.Drawing.Size(38, 28);

            this.btDigito3.TabIndex = 12;
            this.btDigito3.Text = "3";
            this.btDigito3.UseVisualStyleBackColor = true;

            this.btDigito3.Click +=
                new System.EventHandler(this.btDigito_Click);

            // 
            // btPor
            // 
            this.btPor.Location =
                new System.Drawing.Point(144, 118);

            this.btPor.Name = "btPor";

            this.btPor.Size =
                new System.Drawing.Size(38, 28);

            this.btPor.TabIndex = 13;
            this.btPor.Text = "x";
            this.btPor.UseVisualStyleBackColor = true;

            this.btPor.Click +=
                new System.EventHandler(this.btOperacion_Click);

            // 
            // btMas
            // 
            this.btMas.Location =
                new System.Drawing.Point(188, 118);

            this.btMas.Name = "btMas";

            this.btMas.Size =
                new System.Drawing.Size(46, 28);

            this.btMas.TabIndex = 14;
            this.btMas.Text = "+";
            this.btMas.UseVisualStyleBackColor = true;

            this.btMas.Click +=
                new System.EventHandler(this.btOperacion_Click);

            // 
            // btDigito0
            // 
            this.btDigito0.Location =
                new System.Drawing.Point(12, 152);

            this.btDigito0.Name = "btDigito0";

            this.btDigito0.Size =
                new System.Drawing.Size(82, 28);

            this.btDigito0.TabIndex = 15;
            this.btDigito0.Text = "0";
            this.btDigito0.UseVisualStyleBackColor = true;

            this.btDigito0.Click +=
                new System.EventHandler(this.btDigito_Click);

            // 
            // btComaDec
            // 
            this.btComaDec.Location =
                new System.Drawing.Point(100, 152);

            this.btComaDec.Name = "btComaDec";

            this.btComaDec.Size =
                new System.Drawing.Size(38, 28);

            this.btComaDec.TabIndex = 16;
            this.btComaDec.Text = ",";
            this.btComaDec.UseVisualStyleBackColor = true;

            this.btComaDec.Click +=
                new System.EventHandler(this.btComaDec_Click);

            // 
            // btIgual
            // 
            this.btIgual.Location =
                new System.Drawing.Point(144, 152);

            this.btIgual.Name = "btIgual";

            this.btIgual.Size =
                new System.Drawing.Size(38, 28);

            this.btIgual.TabIndex = 17;
            this.btIgual.Text = "=";
            this.btIgual.UseVisualStyleBackColor = true;

            this.btIgual.Click +=
                new System.EventHandler(this.btOperacion_Click);

            // 
            // btTantoPorCiento
            // 
            this.btTantoPorCiento.Location =
                new System.Drawing.Point(188, 152);

            this.btTantoPorCiento.Name = "btTantoPorCiento";

            this.btTantoPorCiento.Size =
                new System.Drawing.Size(46, 28);

            this.btTantoPorCiento.TabIndex = 18;
            this.btTantoPorCiento.Text = "%";
            this.btTantoPorCiento.UseVisualStyleBackColor = true;

            this.btTantoPorCiento.Click +=
                new System.EventHandler(
                    this.btTantoPorCiento_Click);

            // 
            // Form1
            // 
            this.AutoScaleDimensions =
                new System.Drawing.SizeF(6F, 13F);

            this.AutoScaleMode =
                System.Windows.Forms.AutoScaleMode.Font;

            this.ClientSize =
                new System.Drawing.Size(246, 192);

            this.Controls.Add(this.btTantoPorCiento);
            this.Controls.Add(this.btIgual);
            this.Controls.Add(this.btComaDec);
            this.Controls.Add(this.btDigito0);

            this.Controls.Add(this.btMas);
            this.Controls.Add(this.btPor);

            this.Controls.Add(this.btDigito3);
            this.Controls.Add(this.btDigito2);
            this.Controls.Add(this.btDigito1);

            this.Controls.Add(this.btMenos);
            this.Controls.Add(this.btDividir);

            this.Controls.Add(this.btDigito6);
            this.Controls.Add(this.btDigito5);
            this.Controls.Add(this.btDigito4);

            this.Controls.Add(this.btBorrarEntrada);
            this.Controls.Add(this.btIniciar);

            this.Controls.Add(this.btDigito9);
            this.Controls.Add(this.btDigito8);
            this.Controls.Add(this.btDigito7);

            this.Controls.Add(this.etPantalla);

            this.Name = "Form1";
            this.Text = "Calculadora";

            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Label etPantalla;

        private System.Windows.Forms.Button btDigito0;
        private System.Windows.Forms.Button btDigito1;
        private System.Windows.Forms.Button btDigito2;
        private System.Windows.Forms.Button btDigito3;
        private System.Windows.Forms.Button btDigito4;
        private System.Windows.Forms.Button btDigito5;
        private System.Windows.Forms.Button btDigito6;
        private System.Windows.Forms.Button btDigito7;
        private System.Windows.Forms.Button btDigito8;
        private System.Windows.Forms.Button btDigito9;

        private System.Windows.Forms.Button btMas;
        private System.Windows.Forms.Button btMenos;
        private System.Windows.Forms.Button btPor;
        private System.Windows.Forms.Button btDividir;
        private System.Windows.Forms.Button btIgual;

        private System.Windows.Forms.Button btComaDec;
        private System.Windows.Forms.Button btTantoPorCiento;
        private System.Windows.Forms.Button btIniciar;
        private System.Windows.Forms.Button btBorrarEntrada;
    }
}
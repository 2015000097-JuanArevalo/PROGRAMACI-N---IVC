namespace Ejercicio3_JuanArevalo_IVC_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a, b, r;
            a = Convert.ToInt32(textBox1.Text);
            b = Convert.ToInt32(textBox2.Text);
            //
            r = a + b;
            textBox3.Text = r.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label3.Text = ((Convert.ToInt32(textBox1.Text)) - (Convert.ToInt32(textBox2))).ToString();
        }
    }
}

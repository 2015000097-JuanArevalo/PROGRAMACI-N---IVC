namespace Ejercicio2_JUanArevalo_IVC_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            progressBar1.Value = 0;
            for (int i = 0; i <= 10; i++)
            {
                progressBar1.Value = 1;
                Application.DoEvents();
                Thread.Sleep(30);
            }

            string genero = "";
            if (radioButton1.Checked)
            {
                genero = "Masculino";
            }
            if (radioButton2.Checked)
            {
                genero = "Femenino";
            }

            MessageBox.Show("Datos Personales\n");
        }
    }
}
